﻿using System.Collections;

namespace Program
{
    class Program
    {

        class Items
        {
            public string typeofTitle { get; set; }
            public string authorN { get; set; }
            public int BookId { get; set; }



            public Items(string aTitle, string aAuthor, int aBook)
            {
                typeofTitle = aTitle;
                authorN = aAuthor;
                BookId = aBook;
            }



        }
        public static void mainMenu()
        {
            List<Items> inventory = new List<Items>();
            Dictionary<string, string> my_dictio = new Dictionary<string, string>(){
                                                {"1", "New Books"},
                                                {"2", "Books for Donation"},
                                                {"3", "Books for Repair"},
                                                {"4", "Borrowed Books"},
                                                {"5", "Books for Returning"}};
            Console.WriteLine("Welcome to the Online Library System!\nMain Menu\na. Add Records\nb. Edit Records\nc. Delete Records\nd. Compute Total Number of Books\ne. Display All Records");

            Console.Write("Enter Choice: ");
            string userInput = Console.ReadLine();



            if (userInput == "a")
            {

                Console.WriteLine("Adding a Record");
                Console.WriteLine("*****************************************************************");


                Console.WriteLine("Current Records");

                try
                {

                    foreach (KeyValuePair<string, string> ele2 in my_dictio)
                    {
                        Console.WriteLine("{0} {1}", ele2.Key, ele2.Value);
                    }
                    Console.Write("Enter New Number of Record: "); string numType = Console.ReadLine();
                    Console.Write("Enter New Record: "); string itemType = Console.ReadLine();
                    my_dictio.Add(numType, itemType);
                    Console.WriteLine("Updated Records");
                    foreach (KeyValuePair<string, string> ele2 in my_dictio)
                    {
                        Console.WriteLine("{0} {1}", ele2.Key, ele2.Value);
                    }
                }
                catch
                {
                    Console.WriteLine("Error.");
                }

                Console.Write("Would you like to continue?[Y/N]: "); string userinput2 = Console.ReadLine();

                if (userinput2.ToUpper() == "Y")
                {

                    int i = 0;
                    do
                    {
                        foreach (KeyValuePair<string, string> ele2 in my_dictio)
                        {
                            Console.WriteLine("{0} {1}", ele2.Key, ele2.Value);
                        }
                        Console.Write("Enter New Number of Record: "); string numTypeAgain = Console.ReadLine();
                        Console.Write("Enter New Record: "); string itemTypeAgain = Console.ReadLine();
                        my_dictio.Add(numTypeAgain, itemTypeAgain);
                        Console.WriteLine("Updated Records");
                        foreach (KeyValuePair<string, string> ele2 in my_dictio)
                        {
                            Console.WriteLine("{0} {1}", ele2.Key, ele2.Value);
                        }



                        Console.Write("Would you like to continue?[Y/N]: "); string userinput3 = Console.ReadLine();
                        if (userinput3 == "Y")
                        {
                            i++;
                        }
                        else
                        {
                            mainMenu();
                        }

                    }
                    while (i < 5);

                }
                else
                {
                    mainMenu();
                }

            }

            else if (userInput == "b")
            {
                Console.WriteLine("*****************************************************************");


                Console.WriteLine("Current Records");

                foreach (KeyValuePair<string, string> ele2 in my_dictio)
                {
                    Console.WriteLine("{0} {1}", ele2.Key, ele2.Value);
                }
                Console.Write("Number of Record to Edit: "); int recordEdit = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter New Record Name: "); string listEdit = Console.ReadLine();
                Console.Write("New Number of Record: "); string newRecord = Console.ReadLine();


                if (recordEdit == 1)
                {
                    Dictionary<string, string> next_dictio =
                        new Dictionary<string, string>(){
                                                {newRecord, listEdit},
                                                {"2", "Books for Donation"},
                                                {"3", "Books for Repair"},
                                                {"4", "Borrowed Books"},
                                                {"5", "Books for Returning"}};

                    Console.WriteLine("*****************************************************************");
                    Console.WriteLine("Updated Records");

                    foreach (KeyValuePair<string, string> ele2 in next_dictio)
                    {
                        Console.WriteLine("{0} {1}", ele2.Key, ele2.Value);
                    }
                }
                else if (recordEdit == 2)
                {
                    Dictionary<string, string> next_dictio =
                        new Dictionary<string, string>(){
                                                {"1", "New Books"},
                                                {newRecord, listEdit},
                                                {"3", "Books for Repair"},
                                                {"4", "Borrowed Books"},
                                                {"5", "Books for Returning"}};

                    Console.WriteLine("*****************************************************************");
                    Console.WriteLine("Updated Records");

                    foreach (KeyValuePair<string, string> ele2 in next_dictio)
                    {
                        Console.WriteLine("{0} {1}", ele2.Key, ele2.Value);
                    }
                }
                else if (recordEdit == 3)
                {
                    Dictionary<string, string> next_dictio =
                        new Dictionary<string, string>(){
                                                {"1", "New Books"},
                                                {"2", "Books for Donation"},
                                                {newRecord, listEdit},
                                                {"4", "Borrowed Books"},
                                                {"5", "Books for Returning"}};

                    Console.WriteLine("*****************************************************************");
                    Console.WriteLine("Updated Records");

                    foreach (KeyValuePair<string, string> ele2 in next_dictio)
                    {
                        Console.WriteLine("{0} {1}", ele2.Key, ele2.Value);
                    }
                }
                else if (recordEdit == 4)
                {
                    Dictionary<string, string> next_dictio =
                        new Dictionary<string, string>(){
                                                {"1", "New Books"},
                                                {"2", "Books for Donation"},
                                                {"3", "Books for Repair"},
                                                {newRecord, listEdit},
                                                {"5", "Books for Returning"}};

                    Console.WriteLine("*****************************************************************");
                    Console.WriteLine("Updated Records");

                    foreach (KeyValuePair<string, string> ele2 in next_dictio)
                    {
                        Console.WriteLine("{0} {1}", ele2.Key, ele2.Value);
                    }
                }
                else if (recordEdit == 5)
                {
                    Dictionary<string, string> next_dictio =
                        new Dictionary<string, string>(){
                                                {"1", "New Books"},
                                                {"2", "Books for Donation"},
                                                {"3", "Books for Repair"},
                                                {"4", "Borrowed Books"},
                                                {newRecord, listEdit}};

                    Console.WriteLine("*****************************************************************");
                    Console.WriteLine("Updated Records");

                    foreach (KeyValuePair<string, string> ele2 in next_dictio)
                    {
                        Console.WriteLine("{0} {1}", ele2.Key, ele2.Value);
                    }
                }
                else
                {
                    Console.WriteLine("Invalid Input (Within Range Only)");
                }

                //LOOPING
                Console.Write("Would you like to continue?[Y/N]: "); string userinput2 = Console.ReadLine();

                if (userinput2.ToUpper() == "Y")
                {
                    mainMenu();
                }
                else
                {
                    System.Environment.Exit(1);
                }
            }

            else if (userInput == "c")
            {
                Console.WriteLine("Deleting a Record");
                Console.WriteLine("*****************************************************************");


                Console.WriteLine("Current Records");

                foreach (KeyValuePair<string, string> ele2 in my_dictio)
                {
                    Console.WriteLine("{0} {1}", ele2.Key, ele2.Value);
                }
                Console.Write("Enter Value Number to Remove: "); string recordRemove = Console.ReadLine();

                if (int.Parse(recordRemove) < 6 && int.Parse(recordRemove) > 0)
                {
                    Dictionary<string, string> new_dictio =
                            new Dictionary<string, string>(){
                                                    {"1", "New Books"},
                                                    {"2", "Books for Donation"},
                                                    {"3", "Books for Repair"},
                                                    {"4", "Borrowed Books"},
                                                    {"5", "Books for Returning"}};

                    new_dictio.Remove(recordRemove);
                    Console.WriteLine("*****************************************************************");
                    Console.WriteLine("Updated Records");

                    foreach (KeyValuePair<string, string> ele2 in new_dictio)
                    {
                        Console.WriteLine("{0} {1}", ele2.Key, ele2.Value);
                    }

                }
                else
                {
                    Console.WriteLine("Invalid Input (Within Range Only)");



                }
                //LOOPING
                Console.Write("Would you like to continue?[Y/N]: "); string userinput2 = Console.ReadLine();

                if (userinput2.ToUpper() == "Y")
                {
                    mainMenu();
                }
                else
                {
                    System.Environment.Exit(1);
                }
            }
            else if (userInput == "d")
            {
                Items item1 = new Items("Constellation", "John Howard", 1);
                Items item2 = new Items("Art of War", "Leonard Jay", 2);
                Items item3 = new Items("Atomic Habit", "Powell Land", 3);
                Items item4 = new Items("Just Do It", "Nike Allen", 4);
                Items item5 = new Items("Feel Today", "Prince Ray", 5);
                Items item6 = new Items("Bartender", "John Whale", 6);
                Items item7 = new Items("Darkness", "Jordan Clark", 7);
                Items item8 = new Items("Whistle Blower", "Pine Jean", 8);
                Items item9 = new Items("Black Hole", "Neil Maze", 9);
                Items item10 = new Items("Extended Sea", "Keshi Wheel", 10);
                Items item11 = new Items("Maze Runner", "Crystal Zeyn", 11);
                Items item12 = new Items("The White House", "Joe Yusi", 12);
                Items item13 = new Items("Nevermind", "Regina Tan", 13);
                Items item14 = new Items("Business Mind", "Peter Carry", 14);
                Items item15 = new Items("Make Your Life", "Bob Andrew", 15);
                Items item16 = new Items("Requiem of Soul", "June Hailey", 16);
                Items item17 = new Items("Monkey Business", "Milly Hill", 17);
                Items item18 = new Items("Finding Purpose", "Mark Anthony", 18);
                Items item19 = new Items("Full of Misery", "Adie Might", 19);
                Items item20 = new Items("Science of Life", "Chinnie Mercy", 20);
                Items item21 = new Items("Not Your Day", "Steven Silver", 21);
                Items item22 = new Items("Healthy Way", "John Silva", 22);
                Items item23 = new Items("Busy Trip", "Connor Tray", 23);
                Items item24 = new Items("Fight Always", "Vladimir Lou", 24);
                Items item25 = new Items("Uphill Front", "Danny Eagle", 25);

                inventory.Add(item1);
                inventory.Add(item2);
                inventory.Add(item3);
                inventory.Add(item4);
                inventory.Add(item5);
                inventory.Add(item6);
                inventory.Add(item7);
                inventory.Add(item8);
                inventory.Add(item9);
                inventory.Add(item10);
                inventory.Add(item11);
                inventory.Add(item12);
                inventory.Add(item13);
                inventory.Add(item14);
                inventory.Add(item15);
                inventory.Add(item16);
                inventory.Add(item17);
                inventory.Add(item18);
                inventory.Add(item19);
                inventory.Add(item20);
                inventory.Add(item21);
                inventory.Add(item22);
                inventory.Add(item23);
                inventory.Add(item24);
                inventory.Add(item25);

                Console.WriteLine("Total Number of Books: " + inventory.Count);


                Console.Write("Would you like to continue?[Y/N]: "); string userinput2 = Console.ReadLine();

                if (userinput2.ToUpper() == "Y")
                {
                    mainMenu();
                }
                else
                {
                    System.Environment.Exit(1);
                }

            }
            else if (userInput == "e")
            {
                Console.WriteLine("*****************************************************************");
                Console.WriteLine("Current Records");
                if (userInput == "e")
                {
                    Console.WriteLine("1. New Books\n2. Books for Donation\n3. Books for Repair\n4. Borrowed Books\n5. Books for Returning\n6. Exit");
                    Console.Write("Enter your choice: ");
                    int num_input = Convert.ToInt32(Console.ReadLine());
                    if (num_input == 1)
                    {



                        Items item1 = new Items("Constellation", "John Howard", 1);
                        Items item2 = new Items("Art of War", "Leonard Jay", 2);
                        Items item3 = new Items("Atomic Habit", "Powell Land", 3);
                        Items item4 = new Items("Just Do It", "Nike Allen", 4);
                        Items item5 = new Items("Feel Today", "Prince Ray", 5);

                        inventory.Add(item1);
                        inventory.Add(item2);
                        inventory.Add(item3);
                        inventory.Add(item4);
                        inventory.Add(item5);
                        foreach (Items item in inventory)
                        {
                            Console.WriteLine("*****************************************************************");
                            Console.WriteLine("Title: " + item.typeofTitle);
                            Console.WriteLine("Author: " + item.authorN);
                            Console.WriteLine("ID: " + item.BookId);

                        }


                    }
                    else if (num_input == 2)
                    {
                        Items item6 = new Items("Bartender", "John Whale", 6);
                        Items item7 = new Items("Darkness", "Jordan Clark", 7);
                        Items item8 = new Items("Whistle Blower", "Pine Jean", 8);
                        Items item9 = new Items("Black Hole", "Neil Maze", 9);
                        Items item10 = new Items("Extended Sea", "Keshi Wheel", 10);

                        inventory.Add(item6);
                        inventory.Add(item7);
                        inventory.Add(item8);
                        inventory.Add(item9);
                        inventory.Add(item10);
                        foreach (Items item in inventory)
                        {
                            Console.WriteLine("*****************************************************************");
                            Console.WriteLine("Title: " + item.typeofTitle);
                            Console.WriteLine("Author: " + item.authorN);
                            Console.WriteLine("ID: " + item.BookId);

                        }

                    }
                    else if (num_input == 3)
                    {
                        Items item11 = new Items("Maze Runner", "Crystal Zeyn", 11);
                        Items item12 = new Items("The White House", "Joe Yusi", 12);
                        Items item13 = new Items("Nevermind", "Regina Tan", 13);
                        Items item14 = new Items("Business Mind", "Peter Carry", 14);
                        Items item15 = new Items("Make Your Life", "Bob Andrew", 15);

                        inventory.Add(item11);
                        inventory.Add(item12);
                        inventory.Add(item13);
                        inventory.Add(item14);
                        inventory.Add(item15);
                        foreach (Items item in inventory)
                        {
                            Console.WriteLine("*****************************************************************");
                            Console.WriteLine("Title: " + item.typeofTitle);
                            Console.WriteLine("Author: " + item.authorN);
                            Console.WriteLine("ID: " + item.BookId);

                        }

                    }
                    else if (num_input == 4)
                    {
                        Items item16 = new Items("Requiem of Soul", "June Hailey", 16);
                        Items item17 = new Items("Monkey Business", "Milly Hill", 17);
                        Items item18 = new Items("Finding Purpose", "Mark Anthony", 18);
                        Items item19 = new Items("Full of Misery", "Adie Might", 19);
                        Items item20 = new Items("Science of Life", "Chinnie Mercy", 20);

                        inventory.Add(item16);
                        inventory.Add(item17);
                        inventory.Add(item18);
                        inventory.Add(item19);
                        inventory.Add(item20);
                        foreach (Items item in inventory)
                        {
                            Console.WriteLine("*****************************************************************");
                            Console.WriteLine("Title: " + item.typeofTitle);
                            Console.WriteLine("Author: " + item.authorN);
                            Console.WriteLine("ID: " + item.BookId);

                        }

                    }
                    else if (num_input == 5)
                    {
                        Items item21 = new Items("Not Your Day", "Steven Silver", 21);
                        Items item22 = new Items("Healthy Way", "John Silva", 22);
                        Items item23 = new Items("Busy Trip", "Connor Tray", 23);
                        Items item24 = new Items("Fight Always", "Vladimir Lou", 24);
                        Items item25 = new Items("Uphill Front", "Danny Eagle", 25);

                        inventory.Add(item21);
                        inventory.Add(item22);
                        inventory.Add(item23);
                        inventory.Add(item24);
                        inventory.Add(item25);
                        foreach (Items item in inventory)
                        {
                            Console.WriteLine("*****************************************************************");
                            Console.WriteLine("Title: " + item.typeofTitle);
                            Console.WriteLine("Author: " + item.authorN);
                            Console.WriteLine("ID: " + item.BookId);

                        }

                    }
                    else if (num_input == 6)
                    {
                        System.Environment.Exit(1);
                    }
                    else
                    {
                        mainMenu();
                    }

                }

                Console.Write("Would you like to continue?[Y/N]: "); string userinput2 = Console.ReadLine();


                if (userinput2.ToUpper() == "Y")
                {
                    mainMenu();
                }
                else
                {
                    System.Environment.Exit(1);
                }
            }

        }


        static void Main(string[] args)
        {
            mainMenu();
        }


    }
}


